import 'package:flutter/material.dart';

class TextComposer extends StatefulWidget {
  TextComposer(this.sendMessage);
  final Function({String text}) sendMessage;

  @override
  State<StatefulWidget> createState() {
    return TextComposerState();
  }
}

class TextComposerState extends State<TextComposer> {

  final _textController = TextEditingController();
  bool _isComposing = false; 

  @override
  Widget build(BuildContext context) {
      return Scaffold(
      body: IconTheme(
        data: IconThemeData(color: Theme.of(context).accentColor),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 8.0),
          child: Row(
            children: <Widget>[
              Container(
                child: IconButton(icon: Icon(Icons.photo_camera),
                 onPressed: () async{

                 }, ),
              ),
              Expanded(child: TextField(
                controller: _textController,
                decoration: InputDecoration.collapsed(hintText: "Enviar Mensagem"),
                onChanged: (text){
                  setState(() {
                    _isComposing = text.length > 0; 
                  });
                },
                onSubmitted: (text){
                  widget.sendMessage(text: text);
                  _reset();
                },
              )),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 8.0),
                child: IconButton(icon: Icon(Icons.send),
                  onPressed: _isComposing ? () {
                    widget.sendMessage(text: _textController.text);
                    print(_textController.text);
                    _reset();
                  } : null,
                  ) ,
                  )
            ],
          ),
        )
      ) ,
    );
  }

  void _reset() {
    _textController.clear();
    setState(() {
      _isComposing = false;
    });
  }

}