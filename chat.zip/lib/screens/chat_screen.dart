import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:chat/screens/text_composer.dart';

class ChatScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return ChatScreenState();
  }
}

class ChatScreenState extends State<ChatScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Chat App"),
      ),
      body:  TextComposer(_sendMessage),
    );
  }

  void _sendMessage({String? text}) async {
    final CollectionReference _mensagens = FirebaseFirestore.instance.collection("mensagens");
    _mensagens.add({"text": text});
    print("dado enviado para o Firebase");
  }
}